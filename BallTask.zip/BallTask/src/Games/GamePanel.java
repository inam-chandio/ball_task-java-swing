package Games;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

class GamePanel extends JPanel {
    private List<Target> targets;
    private Ball ball;
    private boolean isBallMoving;
    private Timer animationTimer;
    private GameState gameState;
    private Runnable statusUpdateCallback;
    private Runnable levelCompleteCallback;
    private static final double GRAVITY = 0.5;
    private static final int BASE_TARGET_POINTS = 100;
    private static final double LAUNCH_POWER = 15.0;
    private Timer launchTimer;

    public GamePanel(GameState gameState, Runnable statusUpdateCallback, Runnable levelCompleteCallback) {
        this.gameState = gameState;
        this.statusUpdateCallback = statusUpdateCallback;
        this.levelCompleteCallback = levelCompleteCallback;

        setPreferredSize(new Dimension(800, 600));
        targets = new ArrayList<>();
        ball = new Ball(50, 500, 15);

        setupAnimationTimer();
        setupLaunchTimer();
        setBackground(new Color(240, 240, 255));

        initializeTargets();
    }

    private void setupLaunchTimer() {
        // Timer to automatically launch the ball every few seconds
        launchTimer = new Timer(3000, e -> {
            if (!isBallMoving) {
                automaticLaunch();
            }
        });
        launchTimer.start();
    }

    private void automaticLaunch() {
        if (gameState.getRemainingShots() > 0) {
            Random rand = new Random();
            // Generate random angle between 0 and -75 degrees (upward)
            double angle = -rand.nextDouble() * 75 * Math.PI / 180;

            // Calculate velocity components using the angle
            double vx = LAUNCH_POWER * Math.cos(angle);
            double vy = LAUNCH_POWER * Math.sin(angle);

            ball = new Ball(50, 500, 15);
            ball.setVelocity(vx, vy);
            isBallMoving = true;
            gameState.decrementShots();
            statusUpdateCallback.run();
            animationTimer.start();
        }
    }

    private void initializeTargets() {
        targets.clear();
        Random rand = new Random();
        int numTargets = 5 + gameState.getLevel();

        for (int i = 0; i < numTargets; i++) {
            int x = rand.nextInt(700) + 50;
            int y = rand.nextInt(400) + 50;
            int size = rand.nextInt(20) + 30;
            targets.add(new Target(x, y, size, size, BASE_TARGET_POINTS));
        }
    }

    private void setupAnimationTimer() {
        animationTimer = new Timer(16, e -> {
            if (isBallMoving) {
                updateBallPosition();
                checkCollisions();
                repaint();
            }
        });
    }

    private void updateBallPosition() {
        ball.update(GRAVITY);

        // Stop ball if it goes off screen
        if (ball.getX() < 0 || ball.getX() > getWidth() || ball.getY() > getHeight()) {
            resetBall();
        }
    }

    private void checkCollisions() {
        Iterator<Target> iterator = targets.iterator();
        while (iterator.hasNext()) {
            Target target = iterator.next();
            if (target.intersects(ball)) {
                gameState.incrementScore(target.getPoints());
                gameState.incrementTargetsHit();
                iterator.remove();
                statusUpdateCallback.run();

                if (targets.isEmpty()) {
                    levelCompleteCallback.run();
                    resetBall();
                    return;
                }
            }
        }

        if (gameState.getRemainingShots() == 0 && !isBallMoving && !targets.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Game Over!\nFinal Score: " + gameState.getScore());
            resetGame();
        }
    }

    private void resetBall() {
        isBallMoving = false;
        animationTimer.stop();
    }

    public void resetGame() {
        gameState.resetForNewLevel(1);
        initializeTargets();
        resetBall();
        ball = new Ball(50, 500, 15);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw targets
        for (Target target : targets) {
            target.draw(g2d);
        }

        // Draw ball
        ball.draw(g2d);
    }
}