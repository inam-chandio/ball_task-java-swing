package Games;

import javax.swing.*;
import java.awt.*;

public class BallTargetGame extends JFrame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new BallTargetGame().setVisible(true);
        });
    }

    private GamePanel gamePanel;
    private JPanel statusPanel;
    private JLabel scoreLabel;
    private JLabel levelLabel;
    private JLabel shotsLabel;
    private JButton resetButton;
    private GameState gameState;

    public BallTargetGame() {
        setTitle("Ball Target Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        gameState = new GameState();
        initializeComponents();
        setupLayout();
    }

    private void initializeComponents() {
        gamePanel = new GamePanel(gameState, this::updateStatusLabels, this::handleLevelComplete);

        statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
        statusPanel.setBackground(new Color(230, 230, 230));

        scoreLabel = new JLabel("Score: 0");
        levelLabel = new JLabel("Level: 1");
        shotsLabel = new JLabel("Shots: 5");

        Font labelFont = new Font("Arial", Font.BOLD, 16);
        scoreLabel.setFont(labelFont);
        levelLabel.setFont(labelFont);
        shotsLabel.setFont(labelFont);

        resetButton = new JButton("Reset Game");
        resetButton.setFont(labelFont);
        resetButton.addActionListener(e -> resetGame());
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        statusPanel.add(scoreLabel);
        statusPanel.add(levelLabel);
        statusPanel.add(shotsLabel);
        statusPanel.add(resetButton);
        add(statusPanel, BorderLayout.NORTH);
        add(gamePanel, BorderLayout.CENTER);
    }

    private void updateStatusLabels() {
        scoreLabel.setText("Score: " + gameState.getScore());
        levelLabel.setText("Level: " + gameState.getLevel());
        shotsLabel.setText("Shots: " + gameState.getRemainingShots());
    }

    private void handleLevelComplete() {
        int nextLevel = gameState.getLevel() + 1;
        gameState.resetForNewLevel(nextLevel);
        gamePanel.resetGame();
        updateStatusLabels();
        JOptionPane.showMessageDialog(this, "Level " + (nextLevel - 1) + " completed! Moving to Level " + nextLevel);
    }

    private void resetGame() {
        gameState.resetForNewLevel(1);
        gamePanel.resetGame();
        updateStatusLabels();
    }

    // Add this method to expose the game state for testing
    public GameState getGameState() {
        return gameState;
    }
}