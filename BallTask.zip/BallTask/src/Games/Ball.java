package Games;

import java.awt.*;
import java.awt.image.BufferedImage;

class Ball {
    private double x, y;
    private double vx, vy;
    private final int radius;
    private final BufferedImage image;

    public Ball(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.image = ImageLoader.getMovingBallImage();
    }

    public void setVelocity(double vx, double vy) {
        this.vx = vx;
        this.vy = vy;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getVx() {
        return vx;
    }

    public double getVy() {
        return vy;
    }

    public void update(double gravity) {
        x += vx;
        y += vy;
        vy += gravity;
    }

    public void draw(Graphics2D g) {
        if (image != null) {
            int drawX = (int)(x - radius);
            int drawY = (int)(y - radius);
            int size = radius * 2;
            g.drawImage(image, drawX, drawY, size, size, null);
        } else {
            g.setColor(new Color(30, 144, 255));
            g.fillOval((int)(x - radius), (int)(y - radius), 2 * radius, 2 * radius);
        }
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public int getRadius() { return radius; }
}