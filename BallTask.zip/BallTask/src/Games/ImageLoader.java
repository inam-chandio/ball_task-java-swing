package Games;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ImageLoader {
    private static BufferedImage movingBallImage;
    private static final Map<Integer, BufferedImage> targetImages = new HashMap<>();
    private static final String RESOURCE_PATH = "C:\\Users\\HYDRA\\Pictures\\BallTask\\src\\resources";

    static {
        loadImages();
    }

    private static void loadImages() {
        try {
            // Load the moving ball image (1.png)
            movingBallImage = ImageIO.read(new File(RESOURCE_PATH + "\\1.png"));

            // Load target images (2.png through 5.png)
            for (int i = 2; i <= 5; i++) {
                String imagePath = RESOURCE_PATH + "\\" + i + ".png";
                BufferedImage image = ImageIO.read(new File(imagePath));
                targetImages.put(i, image);
            }
        } catch (IOException e) {
            System.err.println("Error loading images: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static BufferedImage getMovingBallImage() {
        return movingBallImage;
    }

    public static BufferedImage getRandomTargetImage() {
        int randomIndex = (int)(Math.random() * targetImages.size()) + 2;
        return targetImages.get(randomIndex);
    }
}