package Games;

import java.awt.*;
import java.awt.image.BufferedImage;

class Target {
    private int x, y, width, height;
    private int points;
    private BufferedImage image;

    public Target(int x, int y, int width, int height, int points) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.points = points;
        this.image = ImageLoader.getRandomTargetImage();
    }

    public void draw(Graphics2D g) {
        if (image != null) {
            g.drawImage(image, x, y, width, height, null);
        } else {
            // Fallback to original green circle if image loading fails
            g.setColor(Color.GREEN);
            g.fillOval(x, y, width, height);
        }
    }

    public boolean intersects(Ball ball) {
        double ballX = ball.getX();
        double ballY = ball.getY();
        int ballRadius = ball.getRadius();
        return ballX + ballRadius > x && ballX - ballRadius < x + width &&
                ballY + ballRadius > y && ballY - ballRadius < y + height;
    }

    // Add getter methods
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getPoints() {
        return points;
    }
}