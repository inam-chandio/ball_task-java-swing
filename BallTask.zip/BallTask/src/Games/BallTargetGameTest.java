package Games;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class BallTargetGameTest {
    private BallTargetGame game;
    private GameState gameState;

    @Before
    public void setUp() {
        game = new BallTargetGame();
        gameState = game.getGameState();
    }

    @Test
    public void testInitialGameState() {
        assertEquals(0, gameState.getScore());
        assertEquals(1, gameState.getLevel());
        assertEquals(6, gameState.getRemainingShots());
    }

    @Test
    public void testGameStateScoring() {
        gameState.incrementScore(100);
        assertEquals(100, gameState.getScore());
    }

    @Test
    public void testGameStateLevelProgression() {
        gameState.resetForNewLevel(2);
        assertEquals(2, gameState.getLevel());
        assertEquals(7, gameState.getRemainingShots());
    }
}