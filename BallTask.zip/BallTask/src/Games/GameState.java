package Games;

public class GameState {
    private int score;
    private int level;
    private int remainingShots;
    private int targetsHit;

    public GameState() {
        resetForNewLevel(1);
    }

    public void resetForNewLevel(int level) {
        this.level = level;
        this.remainingShots = 5 + level;
        this.targetsHit = 0;
    }

    public void incrementScore(int points) {
        score += points;
    }

    public void incrementTargetsHit() {
        targetsHit++;
    }

    public void decrementShots() {
        remainingShots--;
    }

    public int getScore() { return score; }
    public int getLevel() { return level; }
    public int getRemainingShots() { return remainingShots; }
    public int getTargetsHit() { return targetsHit; }
}